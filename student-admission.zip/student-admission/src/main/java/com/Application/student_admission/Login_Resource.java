package com.Application.student_admission;

import java.io.IOException;
import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;

import entity_bean_classes.Admin_table;
import entity_bean_classes.Number_of_colleges;

@Path("Admin_Login")

public class Login_Resource {
	@SuppressWarnings("unused")
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	public ArrayList<String> getPost(ArrayList<String> login_detals) throws IOException, ServletException {
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("StudentPU");
		EntityManager em = emf.createEntityManager();
		em.getTransaction().begin();
		Admin_table user_details = em.find(Admin_table.class, login_detals.get(0));
		em.getTransaction().commit();
		
		ArrayList<String> status = new ArrayList<String>();
		if (user_details != null) {
			if (user_details.getPass().equals(login_detals.get(1)))
				status.add(user_details.getAdmin().getCollege_code());
			else
				status.add("password_wrong");
		} else {
			status.add("no_user_available");
		}
		return status;
	}
}
