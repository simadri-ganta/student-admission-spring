package com.Application.student_admission;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import business_logic.Alloted_dept_check;
import entity_bean_classes.Number_of_colleges;
import entity_bean_classes.Registration_table;
import entity_bean_classes.Selected_students;

@Path("confirm_allotment")

public class Final_allotment {
	@SuppressWarnings("unchecked")
	@GET
	@Path("{college_code}")
	@Produces(MediaType.APPLICATION_JSON)
	public ArrayList<Integer> getPost(@PathParam("college_code") String college_code) throws IOException {
		System.out.println("cominfg allotmen rest");
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("StudentPU");
		EntityManager em = emf.createEntityManager();
		ArrayList<String> list = new ArrayList<String>();
		List<Object> resultlist = em
				.createNativeQuery("select * from Registration_table where percentage>89 and college_choice1="
						+ (char) 34 + college_code + (char) 34 + " order by Date;")
				.getResultList();
		for (int i = 0; i < resultlist.size(); i++) {
			Object[] row = (Object[]) resultlist.get(i);
			list.add(list.size(), (String) row[0]);
		}
		List<Object> resultlist1 = em
				.createNativeQuery("select * from Registration_table where percentage<90 and college_choice1="
						+ (char) 34 + college_code + (char) 34 + " order by percentage DESC;")
				.getResultList();

		for (int i = 0; i < resultlist1.size(); i++) {
			Object[] row = (Object[]) resultlist1.get(i);
			System.out.println(Arrays.toString(row));
			list.add(list.size(), (String) row[0]);

		}
		System.out.println(list);
		ArrayList<String> registered = new ArrayList<String>();

		Iterator<String> iter = list.iterator();
		while (iter.hasNext()) {
			String name=iter.next();
			Registration_table value = em.find(Registration_table.class, name);
			Selected_students selected_students = new Selected_students();
			selected_students.setName(value.getName());
			selected_students.setPercentage(value.getPercentage());
			selected_students.setMarks(value.getMarks());
			selected_students.setBoard(value.getBoard());
			selected_students.setDepartment(value.getDepartment());
			selected_students.setGpa(value.getGpa());
			selected_students.setJoined_date(value.getDate());
			selected_students.setSchool(value.getSchool());
			selected_students.setCollege_code(value.getCollege_choice1());
			Number_of_colleges val = em.find(Number_of_colleges.class, value.getCollege_choice1());
			selected_students.setCollege_name(val.getCollege_name());
			String alotted_dept = new Alloted_dept_check().check_and_allot(value.getDepartment(), college_code);
			System.out.println(alotted_dept + "dept");
			if (alotted_dept.equals("no_seats")) {
				System.out.println("seats finished");

			} else {
				EntityManagerFactory emf1 = Persistence.createEntityManagerFactory("StudentPU");
				EntityManager em1 = emf.createEntityManager();
				selected_students.setAlloted_department(alotted_dept);
				em1.getTransaction().begin();
				Selected_students o = em1.find(Selected_students.class, name);
				if(o==null) {
				em1.persist(selected_students);
				em1.getTransaction().commit();
				registered.add(selected_students.getName());
				emf1.close();
				}
				

			}
		}

		ArrayList<Integer> list1 = new ArrayList<Integer>();
		System.out.println(list1);
		return list1;
	}
}
