package com.Application.student_admission;

import java.util.ArrayList;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.servlet.Registration;
import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import entity_bean_classes.Registration_table;

@Path("new_registeration")
public class Registeration_resource {
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.TEXT_PLAIN)
	public String get_register(ArrayList<String> details) {
		System.out.println("my details coming" + details);

		System.out.println("inside register");
		Registration_table register=new Registration_table();
		register.setName(details.get(0));
		register.setBoard(details.get(1));
		register.setMarks(details.get(2));
		register.setGpa(details.get(3));
		register.setPercentage(Integer.parseInt(details.get(4)));
		register.setSchool(details.get(5));
		register.setDepartment(details.get(6));
		register.setCollege_choice1(details.get(7));
		register.setCollege_choice2(details.get(8));
		
		
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("StudentPU");
		EntityManager em=emf.createEntityManager();
        em.getTransaction().begin();
        System.out.println(register.toString()+"revfgl;g");
        em.persist(register);
        em.getTransaction().commit();
        em.close();

		return "coming";
	}
}
