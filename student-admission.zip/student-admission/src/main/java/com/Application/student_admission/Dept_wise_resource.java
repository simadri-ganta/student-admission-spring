package com.Application.student_admission;

import java.io.IOException;
import java.util.ArrayList;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("dept_resource")

public class Dept_wise_resource {
    @GET
    @Path("{code}")
    @Produces(MediaType.APPLICATION_JSON)
    public ArrayList<String> getPost(@PathParam("code") String code) throws IOException {
    	System.out.println("cominfg dept rest");
    	Dept_wise_list dept_object=new Dept_wise_list();
    	System.out.println("sdhgfsdh");
    	return dept_object.get_list(code);
    }
}
