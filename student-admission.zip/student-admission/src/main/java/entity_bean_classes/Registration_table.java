package entity_bean_classes;

import javax.persistence.Entity;
import javax.persistence.Id;
@Entity
public class Registration_table {
	@Id
	private String name;
	private String board;
	private String marks;
	private String gpa;
	private int percentage;
	private String school;
	private String department;
	private String college_choice1;
	private String college_choice2;
	private java.util.Date Date = new java.util.Date();
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getBoard() {
		return board;
	}
	public void setBoard(String board) {
		this.board = board;
	}
	public String getMarks() {
		return marks;
	}
	public void setMarks(String marks) {
		this.marks = marks;
	}
	public String getGpa() {
		return gpa;
	}
	public void setGpa(String gpa) {
		this.gpa = gpa;
	}
	public int getPercentage() {
		return percentage;
	}
	public void setPercentage(int percentage) {
		this.percentage = percentage;
	}
	public String getSchool() {
		return school;
	}
	public void setSchool(String school) {
		this.school = school;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public String getCollege_choice1() {
		return college_choice1;
	}
	public void setCollege_choice1(String college_choice1) {
		this.college_choice1 = college_choice1;
	}
	public String getCollege_choice2() {
		return college_choice2;
	}
	public void setCollege_choice2(String college_choice2) {
		this.college_choice2 = college_choice2;
	}
	public java.util.Date getDate() {
		return Date;
	}
	public void setDate(java.util.Date date) {
		Date = date;
	}
	@Override
	public String toString() {
		return "Registration_table [name=" + name + ", board=" + board + ", marks=" + marks + ", gpa=" + gpa
				+ ", percentage=" + percentage + ", school=" + school + ", department=" + department
				+ ", college_choice1=" + college_choice1 + ", college_choice2=" + college_choice2 + ", Date=" + Date
				+ "]";
	}

}
