package entity_bean_classes;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Selected_students {
	@Id
	private String name;
	private String board;
	private String marks;
	private String gpa;
	private int percentage;
	private String school;
	private String department;
	private String alloted_department;
	private String college_name;
	private String college_code;
	private Date joined_date;
	
	public String getCollege_code() {
		return college_code;
	}
	public void setCollege_code(String college_code) {
		this.college_code = college_code;
	}
	public String getCollege_name() {
		return college_name;
	}
	public void setCollege_name(String college_name) {
		this.college_name = college_name;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getBoard() {
		return board;
	}
	public void setBoard(String board) {
		this.board = board;
	}
	public String getMarks() {
		return marks;
	}
	public void setMarks(String marks) {
		this.marks = marks;
	}
	public String getGpa() {
		return gpa;
	}
	public void setGpa(String gpa) {
		this.gpa = gpa;
	}
	public int getPercentage() {
		return percentage;
	}
	public void setPercentage(int percentage) {
		this.percentage = percentage;
	}
	public String getSchool() {
		return school;
	}
	public void setSchool(String school) {
		this.school = school;
	}
	public String getDepartment() {
		return department;
	}
	public void setDepartment(String department) {
		this.department = department;
	}
	public String getAlloted_department() {
		return alloted_department;
	}
	public void setAlloted_department(String alloted_department) {
		this.alloted_department = alloted_department;
	}
	public Date getJoined_date() {
		return joined_date;
	}
	public void setJoined_date(Date joined_date) {
		this.joined_date = joined_date;
	}
	@Override
	public String toString() {
		return "Selected_students [name=" + name + ", board=" + board + ", marks=" + marks + ", gpa=" + gpa
				+ ", percentage=" + percentage + ", school=" + school + ", department=" + department
				+ ", alloted_department=" + alloted_department + ", college_name=" + college_name + ", joined_date="
				+ joined_date + "]";
	}
	

	
	
	
	
	

}
