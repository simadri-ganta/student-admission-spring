package servlet_controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import business_logic.New_college;
@WebServlet("/Main_admin/Login_main_admin")
public class Login_main_admin extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		System.out.println("inside servlet");
		String status_code = request.getParameter("status_code");
		PrintWriter out = response.getWriter();

		switch (status_code) {
		case "new_college":
			New_college newcollege=new New_college();
			newcollege.insertcollege(request);
			break;
		}
	}

}
