package servlet_controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import business_logic.Final_allotment;
import business_logic.Login_validation;
import business_logic.New_college;
import business_logic.Registeration;
import business_logic.status_check;

@WebServlet(urlPatterns = {"/login_admin_home", "/college_admin/parent-control"})
public class Home_admin extends HttpServlet {
    /**
	 * 
	 */
	private static final long serialVersionUID = -564632182673264530L;

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		
		System.out.println("inside servlet");
		String status_code=req.getParameter("status_code");
		PrintWriter out = resp.getWriter();
		
		switch(status_code) {
		case "admin1ogin":
			System.out.println("login");
			new Login_validation().validate(req,resp);
			break;
		case "newapplication":
			System.out.println("coming");
			if(new Registeration().register(req).equals("coming")) {
				resp.sendRedirect("newadmissionform.jsp");
				System.out.println("inserted");
			}
			else {
				System.out.println("not inserted");
				resp.sendRedirect("newadmissionform.jsp");
			}	
			break;
			
		case "confirm":
			System.out.println("coming to confirm sevrlet");
			
			out.println("total "+ new Final_allotment().confirm(req) + " students alloted");
			break;
		case "new_college":
			New_college newcollege=new New_college();
			newcollege.insertcollege(req);
			
			break;
		case "student_status":
			new status_check().check(req,resp);
			break;
			
		}
		
		
		
	}
}
