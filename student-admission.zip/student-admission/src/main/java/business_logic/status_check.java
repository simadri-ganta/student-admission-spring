package business_logic;

import java.util.ArrayList;
import java.util.Arrays;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.MediaType;

public class status_check {

	@SuppressWarnings("unchecked")
	public void check(HttpServletRequest req, HttpServletResponse resp) {
		ArrayList<String> details=new ArrayList<>();
		details.add(req.getParameter("name"));
		String value=req.getParameter("password");
		String[] values = value.split("/",4);
		details.add(values[0]);
		details.add(values[1]);
		details.add(values[3]);
		System.out.println(req.getParameter("name")+" "+Arrays.toString(values));
		ArrayList<String> status=ClientBuilder.newClient()
		.target("http://localhost:8082/student-admission/webapi/status")
		.request(MediaType.APPLICATION_JSON)
		.post(Entity.entity(details, MediaType.APPLICATION_JSON))
		.readEntity(ArrayList.class);
		
	}

}
