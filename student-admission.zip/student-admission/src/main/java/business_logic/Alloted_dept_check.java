package business_logic;

import java.math.BigInteger;

public class Alloted_dept_check {
	private char[] li1=new char[4];

	public String check_and_allot(String department_choice,String college_code) {
	
	
		int p=0;
		Depart_count count=new Depart_count();
		BigInteger cse=count.cse(college_code);
		BigInteger ece=count.ece(college_code);
		BigInteger it=count.it(college_code);
		BigInteger mech=count.mech(college_code);
	
		switch(department_choice) {
		case "cse":
			if(cse.intValue()<5) {									//cse count
				return "cse";
			}
			else {
			    return "no_seat";
			}
		case "e":
			if(ece.intValue()<5) {									//ece count
				System.out.println("ece");
				return "ece";
				
			}
			else {
				return "no_seat";
				
			}
		
		case "it":
		
			if(it.intValue()<5) {                          	   	//It count
				
					return "it";
				}
			else {
				return "no_seat";
			}
		
		case "mech":
		
			if(mech.intValue()<5) {							// mechanicalcount
				System.out.println("mech");
				return "mech";
			}
			else{
				return "no_seat";
			}
		
		default:
			return "no_seats";
		}
		
	}


}
