package business_logic;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;

public class New_college {

	@SuppressWarnings("unchecked")
	public void insertcollege(HttpServletRequest req) {
		ArrayList<String> list=new ArrayList<>();
		
		list.add(req.getParameter("name"));
		list.add(req.getParameter("code"));
		list.add(req.getParameter("rank"));

		Client client =ClientBuilder.newClient();
		WebTarget webTarget = client.target("http://localhost:8082/student-admission/webapi/new_college_entry");
		
		ArrayList<String> status=webTarget.request(MediaType.APPLICATION_JSON).post(Entity.entity(list,MediaType.APPLICATION_JSON)).readEntity(ArrayList.class);
        System.out.println(status.get(0));
		
	}
	

}
