package business_logic;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.core.MediaType;

public class Final_allotment {
	@SuppressWarnings("unchecked")
	public ArrayList<Integer> confirm(HttpServletRequest req){
		Client client =ClientBuilder.newClient();
		return client.target("http://localhost:8082/student-admission/webapi/confirm_allotment/"+req.getSession().getAttribute("code"))
										.request(MediaType.APPLICATION_JSON)
										.get(ArrayList.class);
										
		
	}

}
