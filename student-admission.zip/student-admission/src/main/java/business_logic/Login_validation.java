package business_logic;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.MediaType;

public class Login_validation {

	@SuppressWarnings("unchecked")
	public void validate(HttpServletRequest req, HttpServletResponse resp) throws IOException {
		String id = req.getParameter("name");
		String pass = req.getParameter("pass");
		System.out.println(id + pass);
		ArrayList<String> details = new ArrayList<String>();
		details.add(id);
		details.add(pass);
		Client client = ClientBuilder.newClient();
		ArrayList<String> status = client.target("http://localhost:8082/student-admission/webapi/Admin_Login")
				.request(MediaType.APPLICATION_JSON).post(Entity.entity(details, MediaType.APPLICATION_JSON))
				.readEntity(ArrayList.class);
		if(status!=null) {
		if (status.get(0).equals("password_wrong")) {
			resp.sendRedirect("index.jsp");
		} else if (status.get(0).equals("no_user_available")) {
			resp.sendRedirect("index.jsp");
		} else {
			req.getSession().setAttribute("code", status.get(0));
			System.out.println(req.getSession().getAttribute("code"));
			if(status.get(0).equals("admin")) {
			resp.sendRedirect("Main_admin/admin_home.jsp");
			}
			else {
				resp.sendRedirect("college_admin/admin_home.jsp");
			}
				
		}
		}
	}

}
